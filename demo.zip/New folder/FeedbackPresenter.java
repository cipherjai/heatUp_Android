package com.adrosonic.teg.bestforeignexchange.components.support;

import android.content.Context;

import com.adrosonic.teg.bestforeignexchange.app.TEGApp;
import com.adrosonic.teg.bestforeignexchange.utils.Constants;
import com.adrosonic.teg.contract.SendFeedbackContract;
import com.adrosonic.teg.tegsync.api.TEGService;
import com.adrosonic.teg.tegsync.interactors.FeedbackInteractor;
import com.adrosonic.teg.tegsync.network.Resource;

import javax.inject.Inject;

/**
 * Created by User on 31-08-2017.
 */

public class FeedbackPresenter implements SendFeedbackContract.Presenter {
    private final SendFeedbackContract.View view;
    private final FeedbackInteractor mInteractor;
    private final Context context;


    @Inject
    TEGService service;

    public FeedbackPresenter(SendFeedbackContract.View view, Context context) {
        this.context = context;
        this.view = view;
        ((TEGApp) context.getApplicationContext()).getAppComponent().inject(this);
        mInteractor = new FeedbackInteractor(this.service,1);

    }

    public SendFeedbackContract.View getView() {
        return view;
    }
    @Override
    public void setView(SendFeedbackContract.View view) {
    }

    @Override
    public void setInteractor(SendFeedbackContract.UseCase interactor) {

    }

    @Override
    public void start() {

    }

    @Override
    public void getFeedbackData() {
//        mInteractor.updateType(view.getFeedbackType());
//        mInteractor.updateCustomerName(view.getCustomerName());
//        mInteractor.updateSubject(view.getSubject());
//        mInteractor.updateDayTimeContact(view.getDayTimeContact());
//        mInteractor.updateMobileNumber(view.getCustomerNumber());
//        mInteractor.updateEmail(view.getCustomerEmail());
//        mInteractor.updateCustomerAddress(view.getCustomerAddress());
//        mInteractor.updatePostalCode(view.getPostal());
//        mInteractor.updatePreferredMode(view.getPreferredMode());
//        mInteractor.updateBranch(view.getFeedbackBranch());
//        mInteractor.updatFeedbackDetails(view.getFeedbackDetails());
//        mInteractor.updateHaveYouSpokenToAnyone(view.getHaveYouSpokenToAnyone());
//        mInteractor.updateBuildNumber(view.getBuildNumber());
//        mInteractor.updateVersionNumber(view.getVersionNumber());
//        mInteractor.updateTitle(view.getCustomerTitle());

        mInteractor.updateType("Hello");
        mInteractor.updateCustomerName(view.getCustomerName());
        mInteractor.updateSubject(view.getSubject());
        mInteractor.updateDayTimeContact(view.getDayTimeContact());
        mInteractor.updateMobileNumber(view.getCustomerNumber());
        mInteractor.updateEmail("rahul.wagh@adrosonic.com");
        mInteractor.updateCustomerAddress(view.getCustomerAddress());
        mInteractor.updatePostalCode(view.getPostal());
        mInteractor.updatePreferredMode(view.getPreferredMode());
        mInteractor.updateBranch(view.getFeedbackBranch());
        mInteractor.updatFeedbackDetails(view.getFeedbackDetails());
        mInteractor.updateHaveYouSpokenToAnyone(view.getHaveYouSpokenToAnyone());
        mInteractor.updateBuildNumber(view.getBuildNumber());
        mInteractor.updateVersionNumber(view.getVersionNumber());
        mInteractor.updateTitle(view.getCustomerTitle());

        view.setLoadingIndicator(true);

        mInteractor.sendFeed(new SendFeedbackContract.UseCase.FeedbackCallback() {
            @Override
            public void onCompletion(Resource<String> resource) {
                view.setLoadingIndicator(false);

                switch (resource.status) {
                    case ERROR:
                        view.setLoadingIndicator(false);
                        view.showFeedbackResponse(resource.data,Constants.FEEDBACK_RESPONSE_ERROR);
                        break;
                    case SUCCESS:
                        view.setLoadingIndicator(false);
                        view.showFeedbackResponse(resource.data,Constants.FEEDBACK_RESPONSE_SUCCESS);
                        break;
                    default:
                        break;
                }

            }
        });

    }
}
