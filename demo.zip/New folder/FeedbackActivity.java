package com.adrosonic.teg.bestforeignexchange.components.support;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.adrosonic.teg.bestforeignexchange.R;
import com.adrosonic.teg.bestforeignexchange.app.TEGApp;
import com.adrosonic.teg.bestforeignexchange.utils.Constants;
import com.adrosonic.teg.bestforeignexchange.utils.Utility;
import com.adrosonic.teg.contract.SendFeedbackContract;
import com.adrosonic.teg.tegsync.api.TEGService;
import com.adrosonic.teg.tegsync.interactors.FeedbackInteractor;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Select;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class FeedbackActivity extends AppCompatActivity implements Validator.ValidationListener, SendFeedbackContract.View {

    FeedbackInteractor mInteractor;
    SendFeedbackContract.Presenter mPresenter;

    @BindView(R.id.toolbar_title)
    TextView toolbarTitle;
    @BindView(R.id.toolbar)
    Toolbar mtoolbar;

    @BindView(R.id.button_submit_feedback)
    Button buttonSubmitFeedback;

    @BindView(R.id.spinner_select_branch)
    Spinner spinnerSelectBranch;

    @BindView(R.id.spinner_prefered_contact)
    Spinner spinnerPreferedContact;

    @NotEmpty(message = "Please Enter Address")
    @BindView(R.id.edt_feedback_address)
    TextInputEditText edtFeedbackAddress;

    @NotEmpty(message = "Please Enter Postal Code")
    @BindView(R.id.edt_feedback_postalcode)
    EditText edtFeedbackPostalcode;

    @Select
    @BindView(R.id.spinner_title)
    Spinner spinnerTitle;

    @Email(message = "Please Enter Valid EmailId")
    @BindView(R.id.edt_feedback_email)
    EditText edtFeedbackEmail;

    @NotEmpty(message = "Enter Mobile Number")
    @BindView(R.id.edt_feedback_mobile)
    EditText edtFeedbackMobile;

    @BindView(R.id.edt_feedback_daytime_number)
    EditText edtFeedbackDaytimeNumber;

    @NotEmpty(message = "Please Select Feedback Subject")
    @BindView(R.id.edt_feedback_subject)
    EditText edtFeedbackSubject;

    @NotEmpty(message = "Please Enter Your Name")
    @BindView(R.id.edt_feedback_name)
    EditText edtFeedbackName;

    @Select
    @BindView(R.id.spinner_feedback_type)
    Spinner spinnerFeedbackType;

    @NotEmpty(message = "Enter Feedback")
    @BindView(R.id.edt_feedback_details)
    TextInputEditText edtFeedbackDetails;

    protected Validator validator;
    protected boolean validated;
    @BindView(R.id.inputlayout_email)
    TextInputLayout inputlayoutEmail;

    @Inject
    TEGService tegService;
    @BindView(R.id.edthaveyouspoken)
    TextInputEditText edthaveyouspoken;

    ProgressDialog pd, progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ((TEGApp) this.getApplicationContext()).getAppComponent().inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        ButterKnife.bind(this);

//        validator = new Validator(this);
//        validator.setValidationListener(this);

        mInteractor = new FeedbackInteractor(tegService, 1);
        FeedbackPresenter presenter = new FeedbackPresenter(this, getApplicationContext());
        presenter.setView(this);
        setPresenter(presenter);

        mtoolbar.setNavigationIcon(R.drawable.ic_arrow_back_24dp);
        mtoolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait ...");

    }

    @OnClick(R.id.button_submit_feedback)
    public void onSubmitFeedbackClick() {

        mPresenter.getFeedbackData();


    }

    @Override
    public void onValidationSucceeded() {
        validated = true;


    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        Utility.displayValidationErrors(FeedbackActivity.this, errors);

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }


    @Override
    public void setPresenter(SendFeedbackContract.Presenter presenter) {
        mPresenter = presenter;

    }

    @Override
    public void updateBindings() {

    }

    @Override
    public void setLoadingIndicator(boolean active) {

        if(active){
            progressDialog.show();
        }
        else{
            progressDialog.dismiss();
        }

    }

    @Override
    public void showFeedbackResponse(String response,int status) {

        int title = 0;
        String message="";
        switch (status) {
            case Constants.FEEDBACK_RESPONSE_ERROR:
                title=R.string.feedback_error_title;
                message=response;
                break;

            case Constants.FEEDBACK_RESPONSE_SUCCESS:
                title=R.string.feedback_success_title;
                message="Your feedback ID is: " + response;
                break;

            default:
                break;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setCancelable(true)
                .setNegativeButton("Close",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();

                    }
                });
        AlertDialog alert = builder.create();
        alert.show();


    }

    @Override
    public String getCustomerTitle() {
        return spinnerTitle.getSelectedItem().toString();
    }

    @Override
    public String getFeedbackType() {
        return spinnerFeedbackType.getSelectedItem().toString();
    }

    @Override
    public String getCustomerName() {
        return edtFeedbackName.getText().toString();
    }

    @Override
    public String getSubject() {
        return edtFeedbackSubject.getText().toString();
    }

    @Override
    public String getDayTimeContact() {
        return edtFeedbackDaytimeNumber.getText().toString();
    }

    @Override
    public String getCustomerNumber() {
        return edtFeedbackMobile.getText().toString();
    }

    @Override
    public String getCustomerEmail() {
        return edtFeedbackEmail.getText().toString();
    }

    @Override
    public String getCustomerAddress() {
        return edtFeedbackAddress.getText().toString();
    }

    @Override
    public String getPostal() {
        return edtFeedbackPostalcode.getText().toString();
    }

    @Override
    public String getPreferredMode() {
        return spinnerPreferedContact.getSelectedItem().toString();
    }

    @Override
    public String getFeedbackBranch() {
        return spinnerSelectBranch.getSelectedItem().toString();
    }

    @Override
    public String getFeedbackDetails() {
        return edtFeedbackDetails.getText().toString();
    }

    @Override
    public String getHaveYouSpokenToAnyone() {
        return edthaveyouspoken.getText().toString();
    }

    @Override
    public String getBuildNumber() {
        return "123";
    }

    @Override
    public String getVersionNumber() {
        return "1";
    }


}
