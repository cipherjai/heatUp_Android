package com.adrosonic.teg.tegsync.api;

import com.adrosonic.teg.bestforeignexchange.BuildConfig;
import com.adrosonic.teg.tegmodel.ExchangeRate;
import com.adrosonic.teg.tegmodel.cart.Cart;
import com.adrosonic.teg.tegmodel.feedback.FeedbackModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;


/**
 * Created by User on 01-06-2017.
 */

public interface TEGService {

    @Headers({"access_token:" + BuildConfig.ACCESS_TOKEN,
            "cookie:request_source=" + BuildConfig
            .DEVICE_TYPE})
    @GET("exchangeRateAPI/getExchangeRates")
    Call<List<ExchangeRate>> fetchExchangeRates();

    @Headers({"access_token:" + BuildConfig.ACCESS_TOKEN,
            "cookie:request_source=" + BuildConfig.DEVICE_TYPE})
    @POST("orderAPI/saveOrder?device=and&version=1")
    Call<Cart> saveOrder(@Body Cart body);

    @Headers({"access_token:" + BuildConfig.ACCESS_TOKEN,
            "cookie:request_source=" + BuildConfig.DEVICE_TYPE})
    @GET("branchAPI/getBranchMatrix")
    Call<List<ExchangeRate>> fetchBranchMatrix();

    @Headers({"access_token:" + BuildConfig.ACCESS_TOKEN,
            "cookie:request_source=" + BuildConfig.DEVICE_TYPE})
    @GET("orderAPI/getHTML")
    Call<List<ExchangeRate>> fetchHTML();

    @Headers({"access_token:" + BuildConfig.ACCESS_TOKEN,
            "cookie:request_source=" + BuildConfig.DEVICE_TYPE,
            "Content-Type: text/plain"})
    @POST("feedbackAPI/feedback?device=and")
    Call<String> sendFeedback(@Body String body);

}
