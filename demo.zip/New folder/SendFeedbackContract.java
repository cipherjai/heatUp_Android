package com.adrosonic.teg.contract;

import com.adrosonic.teg.base.BasePresenter;
import com.adrosonic.teg.base.BaseView;
import com.adrosonic.teg.tegmodel.feedback.FeedbackModel;
import com.adrosonic.teg.tegsync.network.Resource;

/**
 * Created by User on 31-08-2017.
 */

public interface SendFeedbackContract {

    interface View extends BaseView<SendFeedbackContract.Presenter> {
    void setLoadingIndicator(boolean active);
    void showFeedbackResponse(String message,int status);

    String getCustomerTitle();
    String getFeedbackType();
    String getCustomerName();
    String getSubject();
    String getDayTimeContact();
    String getCustomerNumber();
    String getCustomerEmail();
    String getCustomerAddress();
    String getPostal();
    String getPreferredMode();
    String getFeedbackBranch();
    String getFeedbackDetails();
    String getHaveYouSpokenToAnyone();
    String getBuildNumber();
    String getVersionNumber();

}

interface Presenter extends BasePresenter<View, UseCase> {
    void getFeedbackData();

}

    interface UseCase {
        interface FeedbackCallback {
            void onCompletion(Resource<String> resource);
        }
    }
}

