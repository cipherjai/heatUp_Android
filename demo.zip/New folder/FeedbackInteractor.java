package com.adrosonic.teg.tegsync.interactors;

import android.support.annotation.NonNull;
import android.util.Log;

import com.adrosonic.teg.contract.SendFeedbackContract;
import com.adrosonic.teg.tegmodel.cart.Cart;
import com.adrosonic.teg.tegmodel.feedback.FeedbackModel;
import com.adrosonic.teg.tegsync.api.TEGService;
import com.adrosonic.teg.tegsync.network.AppExecutors;
import com.adrosonic.teg.tegsync.network.Resource;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import javax.annotation.Nonnull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by User on 31-08-2017.
 */

public class FeedbackInteractor implements SendFeedbackContract.UseCase {

    public static final String TAG = FeedbackInteractor.class.getSimpleName();
    private final TEGService mService;
    private final AppExecutors mExecutors;
    private FeedbackModel feedbackModel;

    public FeedbackInteractor(@NonNull TEGService service, int data) {
        mService = service;
        mExecutors = new AppExecutors();
        feedbackModel=new FeedbackModel();

    }

    public FeedbackModel getFeedbackModel() {
        return feedbackModel;
    }

    public void sendFeed(@NonNull final FeedbackCallback completion) {
        mExecutors.networkIO().execute(new Runnable() {

            @Override
            public void run() {
                String s = new Gson().toJson(feedbackModel);

                mService.sendFeedback(s).enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(Call<String> call, Response<String> response) {
                        if (response.isSuccessful()) {
                            final String body = response.body();
                            Log.v(TAG, "feedback: response successful");
                            Log.v(TAG, "feedback:response:"+body+":"+response.code());


                            mExecutors.mainThread().execute(new Runnable() {
                                @Override
                                public void run() {
                                    if (completion != null) {
                                        completion.onCompletion(Resource.success(body));
                                    }
                                }
                            });
                        } else {
                            try {
                                final String string = response.errorBody()
                                        .string();
                                JSONObject object = new JSONObject(string);
                                final String error = object.getString("error_msg");
                                Log.e(TAG, "feedback: errorBody: \n" + string);
                                mExecutors.mainThread().execute(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (completion != null) {
                                            completion.onCompletion(Resource.error(error, "Failed to get response from server"));
                                        }
                                    }
                                });
                            } catch (IOException | NullPointerException | JSONException e) {
                                Log.e(TAG, "feedback: error exception: \n" + e.getMessage());
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<String> call, final Throwable t) {
                        Log.e(TAG, "feedback: onFailure: \n", t);
                        mExecutors.mainThread().execute(new Runnable() {
                            @Override
                            public void run() {
                                if (completion != null) {
                                    completion.onCompletion(Resource.error(t.getMessage(), "Failed to contact server"));
                                }
                            }
                        });
                    }
                });
            }
        });
    }

    public void updateType(String type){
        feedbackModel.setType(type);
    }

    public void updateCustomerName(String customerName){
        feedbackModel.setCustomerName(customerName);
    }

    public void updateSubject(String subject){
        feedbackModel.setSubject(subject);
    }

    public void updateDayTimeContact(String dayTimeContact){
        feedbackModel.setDayTimeContact(dayTimeContact);
    }

    public void updateMobileNumber(String mobileNumber){
        feedbackModel.setMobileNumber(mobileNumber);
    }

    public void updateEmail(String email){
        feedbackModel.setCustomerEmailAdrress(email);
    }

    public void updateCustomerAddress(String customerAddress){
        feedbackModel.setCustomerAddress(customerAddress);
    }

    public void updatePostalCode(String postalCode){
        feedbackModel.setPostalCode(postalCode);
    }

    public void updatePreferredMode(String preferredMode){
        feedbackModel.setPreferredContactMethod(preferredMode);
    }

    public void updateBranch(String branch){
        feedbackModel.setBranch(branch);
    }


    public void updatFeedbackDetails(String feedbackDetails){
        feedbackModel.setFeedbackDetails(feedbackDetails);
    }

    public void updateHaveYouSpokenToAnyone(String alreadyContacted){
        feedbackModel.setAlreadyContactedDetails(alreadyContacted);
    }

    public void updateBuildNumber(String buildNumber){
        feedbackModel.setBuildNumber(buildNumber);
    }

    public void updateVersionNumber(String versionNumber){
        feedbackModel.setVersionNumber(versionNumber);
    }

    public void updateTitle(String title){
        feedbackModel.setTitle(title);
    }

}
