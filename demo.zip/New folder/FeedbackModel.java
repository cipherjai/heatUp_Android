package com.adrosonic.teg.tegmodel.feedback;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class FeedbackModel {

    @SerializedName("customerAddress")
    @Expose
    private String customerAddress;
    @SerializedName("dayTimeContact")
    @Expose
    private String dayTimeContact;
    @SerializedName("subject")
    @Expose
    private String subject;
    @SerializedName("mobileNumber")
    @Expose
    private String mobileNumber;
    @SerializedName("postalCode")
    @Expose
    private String postalCode;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("branch")
    @Expose
    private String branch;
    @SerializedName("buildNumber")
    @Expose
    private String buildNumber;
    @SerializedName("customerName")
    @Expose
    private String customerName;
    @SerializedName("versionNumber")
    @Expose
    private String versionNumber;
    @SerializedName("customerEmailAdrress")
    @Expose
    private String customerEmailAdrress;
    @SerializedName("preferredContactMethod")
    @Expose
    private String preferredContactMethod;
    @SerializedName("feedbackDetails")
    @Expose
    private String feedbackDetails;
    @SerializedName("alreadyContactedDetails")
    @Expose
    private String alreadyContactedDetails;

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getDayTimeContact() {
        return dayTimeContact;
    }

    public void setDayTimeContact(String dayTimeContact) {
        this.dayTimeContact = dayTimeContact;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getBuildNumber() {
        return buildNumber;
    }

    public void setBuildNumber(String buildNumber) {
        this.buildNumber = buildNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getVersionNumber() {
        return versionNumber;
    }

    public void setVersionNumber(String versionNumber) {
        this.versionNumber = versionNumber;
    }

    public String getCustomerEmailAdrress() {
        return customerEmailAdrress;
    }

    public void setCustomerEmailAdrress(String customerEmailAdrress) {
        this.customerEmailAdrress = customerEmailAdrress;
    }

    public String getPreferredContactMethod() {
        return preferredContactMethod;
    }

    public void setPreferredContactMethod(String preferredContactMethod) {
        this.preferredContactMethod = preferredContactMethod;
    }

    public String getFeedbackDetails() {
        return feedbackDetails;
    }

    public void setFeedbackDetails(String feedbackDetails) {
        this.feedbackDetails = feedbackDetails;
    }

    public String getAlreadyContactedDetails() {
        return alreadyContactedDetails;
    }

    public void setAlreadyContactedDetails(String alreadyContactedDetails) {
        this.alreadyContactedDetails = alreadyContactedDetails;
    }


}